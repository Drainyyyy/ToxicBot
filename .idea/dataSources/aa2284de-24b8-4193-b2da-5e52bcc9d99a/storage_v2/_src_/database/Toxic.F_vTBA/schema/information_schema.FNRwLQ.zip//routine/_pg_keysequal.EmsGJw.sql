create function "_pg_keysequal"(smallint[], smallint[]) returns boolean
  immutable
  parallel safe
  language sql
as
$$
select $1 operator(pg_catalog.<@) $2 and $2 operator(pg_catalog.<@) $1
$$;

alter function "_pg_keysequal"(smallint[], smallint[]) owner to postgres;

